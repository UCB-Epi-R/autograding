install.packages(c("evaluate", "here", "jsonlite", "rlist", "checkr", "assertthat", "dplyr", "reticulate"), repos = "http://cran.us.r-project.org")
